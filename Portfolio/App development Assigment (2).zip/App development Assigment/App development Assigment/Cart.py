


class Cart:
    def __init__(self,item_id,item_name,price,quantity,item_image):
        self.item_id = item_id
        self.item_name = item_name
        self.price = price
        self.quantity = quantity
        self.item_image = item_image


    def set_item_id(self,item_id):
        self.item_id = item_id
    def set_item_name(self,item_name):
        self.item_name = item_name
    def set_price(self,price):
        self.price = price
    def set_quantity(self,quantity):
        self.quantity = quantity
    def set_item_image(self,item_image):
        self.item_image = item_image


    def get_item_id(self):
        return self.item_id
    def get_item_name(self):
        return self.item_name
    def get_price(self):
        return self.price
    def get_quantity(self):
        return self.quantity
    def get_item_image(self):
        return self.item_image