# User appointment class

class User_appointment:
    count_id = 0

    # initializer method
    def __init__(self,first_name,last_name,email_address,location,date_for_dropoff,time_for_dropoff,selling_price,electronic_type_selling,message):
        User_appointment.count_id += 1
        self.user_id = User_appointment.count_id

        self.first_name = first_name
        self.last_name = last_name
        self.email_address = email_address
        self.location = location
        self.date_for_dropoff = date_for_dropoff
        self.time_for_dropoff = time_for_dropoff
        self.selling_price = selling_price
        self.electronic_type_selling = electronic_type_selling
        self.message = message

    def get_user_id(self):
        return self.user_id

    def set_first_name(self,first_name):
        self.first_name = first_name

    def get_first_name(self):
        return self.first_name

    def set_last_name(self,last_name):
        self.last_name = last_name

    def get_last_name(self):
        return self.last_name

    def set_email_address(self,email_address):
        self.email_address = email_address

    def get_email_address(self):
        return self.email_address

    def set_location(self,location):
        self.location = location

    def get_location(self):
        return self.location

    def set_date_for_dropoff(self,date_for_dropoff):
        self.date_for_dropoff = date_for_dropoff

    def get_date_for_dropoff(self):
        return self.date_for_dropoff
    def set_time_for_dropoff(self,time_for_dropoff):
        self.time_for_dropoff = time_for_dropoff

    def get_time_for_dropoff(self):
        return self.time_for_dropoff

    def set_selling_price(self,selling_price):
        self.selling_price = selling_price

    def get_selling_price(self):
        return self.selling_price

    def set_electronic_type_selling(self,electronic_type_selling):
        self.electronic_type_selling= electronic_type_selling

    def get_electronic_type_selling(self):
        return self.electronic_type_selling

    def set_message(self,message):
        self.message = message

    def get_message(self):
        return self.message