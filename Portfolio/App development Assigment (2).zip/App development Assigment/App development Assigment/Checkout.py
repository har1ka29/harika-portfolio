class Checkout:
    def __init__(self,name,email,address,shipping_option,card,cvv,expire_date):
        self.name = name
        self.email = email
        self.address = address
        self.shipping_option = shipping_option
        self.card = card
        self.cvv = cvv
        self.expire_date = expire_date

    def get_name(self):
        return self.name
    def get_email(self):
        return self.email
    def get_address(self):
        return self.address
    def get_shipping_option(self):
        return self.shipping_option
    def get_card(self):
        return self.card
    def get_cvv(self):
        return self.cvv
    def get_expire_date(self):
        return self.expire_date