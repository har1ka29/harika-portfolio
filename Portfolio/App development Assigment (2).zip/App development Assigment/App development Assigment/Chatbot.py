class Chatbot:
    id = 0

    def __init__(self, name, email, type, remarks, date, time):
        Chatbot.id += 1
        self.__id = Chatbot.id
        self.__name = name
        self.__email = email
        self.__type = type
        self.__remarks = remarks
        self.__date = date
        self.__time = time

    def get_id(self):
        return self.__id

    def set_id(self, id):
        self.__id = id

    def get_name(self):
        return self.__name

    def set_name(self, name):
        self.__name = name

    def get_email(self):
        return self.__email

    def set_email(self, email):
        self.__email = email

    def get_type(self):
        return self.__type

    def set_type(self, type):
        self.__type = type

    def get_remarks(self):
        return self.__remarks

    def set_remarks(self, remarks):
        self.__remarks = remarks

    def get_date(self):
        return self.__date

    def set_date(self, date):
        self.__date = date

    def get_time(self):
        return self.__time

    def set_time(self, time):
        self.__time =time