from wtforms import Form, StringField, SelectField, TextAreaField, validators, PasswordField
from wtforms.fields import EmailField, DateField
from wtforms.fields.choices import RadioField
from wtforms.fields.simple import BooleanField, HiddenField
from wtforms.validators import DataRequired, ValidationError
from datetime import datetime

def non_zero_validator_for_selling_price(form, field):
    # Check if the value is zero (either "0" or "0.0")
    if field.data == "0" or field.data == "0.0" or field.data == "0.00":
        raise ValidationError("Your selling price cannot be zero.")


class Create_user_appointment(Form):
    # form field 1
    # ^[A-Za-z]+$ in validators in Regexp. ^ means start of string, $ means end of string, + means string accepts 1 or more alphabetic characters (A-Z for uppercase, a-z for lowercase, space means it accepts space)
    first_name = StringField('First Name', [validators.Length(min=1, max=150), validators.DataRequired(message= "Your first name cannot be empty !"), validators.Regexp('^[A-Za-z]+$', message="Only letters are allowed for first name !")])

    # form field 2
    last_name = StringField('Last Name', [validators.Length(min=1, max=150), validators.DataRequired(), validators.Regexp('^[A-Za-z ]+$', message="Only letters are allowed for last name !")])

    # form field 3
    email = EmailField('Email', [validators.DataRequired(), validators.Email(message= "Invalid Email Address")])

    # form field 4
    location = SelectField('Outlet Location', [validators.DataRequired()], choices=[
        ('',"Select an outlet location"),
        ('Sengkang Grand Mall', 'Sengkang Grand Mall'),
        ('Ang Mo Kio Hub', 'Ang Mo Kio Hub'),
        ('Northpoint City', 'Northpoint City'),
        ('One Holland Village', 'One Holland Village'),
        ('Bedok Mall', 'Bedok Mall'),
        ('Grassroots Club', 'Grassroots Club')], default='')


    # form field 5
    date_for_dropoff = DateField('Select your date for drop-off',  format='%Y-%m-%d',)

    # form field 6
    time_for_dropoff = SelectField('Time for Drop-off', [validators.DataRequired()], choices=[
        ('', 'Select your timing of drop off'),
        ('9:00 AM', '9:00 AM'),
        ('9:30 AM', '9:30 AM'),
        ('10:00 AM', '10:00 AM'),
        ('10:30 AM', '10:30 AM'),
        ('11:00 AM', '11:00 AM'),
        ('11:30 AM', '11:30 AM'),
        ('12:00 AM', '12:00 PM'),
        ('01:00 AM', '12:30 PM'),
        ('01:30 AM', '01:00 PM'),
        ('02:00 PM', '01:30 PM'),
        ('02:30 PM', '02:00 PM'),
        ('03:00 PM', '02:30 PM'),
        ('03:30 PM', '03:30 PM'),
        ('04:00 PM', 'O4:00 PM'),
        ('04:30 PM', '04:30 PM'),
        ('05:00 PM', '05:00 PM'),
        ('05:30 PM', '05:30 PM'),
        ('06:00 PM', '06:00 PM')
    ], default='')

    # form field 7
    # ^\d+(\.\d{1,2})?$ means
    # ^: Asserts the start of the string.
    # \d{1,2}: Matches only one or two digits (0-9).
    # \.: Matches the literal dot (.).
    # \d+: Matches one or more digits after the decimal point.
    # ()?: Makes the decimal part optional (so whole numbers are also valid).
    # $: Asserts the end of the string.
    # non_zero_validator_for_selling_price is a custom validator to check if value is not zero
    selling_price = StringField('Your Expected Selling Price',[validators.DataRequired(),
                                                               validators.Regexp('^\d+(\.\d{1,2})?$', message="Only numbers and decimals up to 2 decimal places are allowed, no letters or spaces allowed for selling price."),
                                                               non_zero_validator_for_selling_price])


    # form field 8
    electronic_type_selling = SelectField('Electronic Devices you are selling', [validators.DataRequired()], choices=[
        ('', 'Select the type of electronic your are selling'),
        ('Smartphone', 'Smartphone'),
        ('Tablet', 'Tablet'),
        ('Laptop', 'Laptop'),
        ('PC', 'PC'),
        ('Camera', 'Camera'),
        ('Speaker/Microphone', 'Speaker/Microphone'),
        ('Electronic watch', 'Electronic watch'),
        ('Charging ports/Connectors', 'Charging port/Connectors')], default='')

    # form field 9
    message = TextAreaField('Message if any (Optional)', [validators.Optional()])


class Staff_Login_Form(Form):
    staff_id = StringField('Staff ID', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])


# Kar chun's code


# Xavier's code
class CreateReportForm(Form):
    staff_id = StringField('Staff ID', [validators.Length(min=1, max=150), validators.DataRequired(),
                                        validators.Regexp(r'^[a-zA-Z]{3}\d{3}+$',
                                                          message="Must start with 3 letters followed by 3 numbers")])
    name = StringField('Name', [validators.Length(min=1, max=150), validators.DataRequired()])
    income = StringField('Income', [validators.Length(min=1, max=150), validators.DataRequired(),
                                    validators.Regexp(r'^\d+(\.\d{1,2})?$',
                                                      message="Please enter a valid number with up to 2 decimal"
                                                              " places.")])
    spending = StringField('Spending', [validators.Length(min=1, max=150), validators.DataRequired(),
                                        validators.Regexp(r'^\d+(\.\d{1,2})?$',
                                                          message="Please enter a valid number with up to 2 decimal"
                                                                  " places.")])

    date = DateField('Date',  format='%Y-%m-%d', validators=[validators.DataRequired()])

# Harika's code
class CreateFeedbackForm(Form):
    name = StringField('Name', [validators.Length(min=1, max=150), validators.DataRequired(),validators.Regexp('^[A-Za-z ]+$', message="Only letters are allowed for name !")])
    email = EmailField('Email', [validators.DataRequired(),validators.Email(message= "Invalid Email Address")])
    who = RadioField('Who are you?', choices=[('B','Buyer'), ('S','Seller')], default='')
    type = SelectField('Type of Feedback', [validators.DataRequired()], choices=[('','Select'), ('Product','About Product'), ('Service','About Service'), ('Overall Experience','About Overall Experience')], default='')
    feedback = StringField('Question', [validators.Length(min=1, max=150), validators.DataRequired()])
    confirm = BooleanField(f"Receive email confirmation of form submission")
    date = HiddenField(default=datetime.now().strftime('%Y-%m-%d'), validators=[DataRequired()])
    time = HiddenField(default=datetime.now().strftime('%H:%M'), validators=[DataRequired()])

# Pham's code

class Create_Contact_Us_Form(Form):
    name = StringField('Name', [validators.Length(min=1, max=150), validators.DataRequired(), validators.Regexp('^[A-Za-z ]+$', message="Only letters are allowed for name !")])
    email = EmailField('Email', [validators.DataRequired(), validators.Email(message= "Invalid Email Address")])
    type = SelectField('Enquiry Type', [validators.DataRequired()], choices=[('', 'Select'), ('B', 'Buyer'), ('S', 'Seller')], default='')
    question = StringField('Question', [validators.Length(min=1, max=150), validators.DataRequired()])
    confirm = BooleanField(f"Receive email confirmation of form submission")
    date = HiddenField(default=datetime.now().strftime('%Y-%m-%d'), validators=[DataRequired()])
    time = HiddenField(default=datetime.now().strftime('%H:%M'), validators=[DataRequired()])

class Create_Chatbot_Form(Form):
    name = StringField('Name', [validators.Length(min=1, max=150), validators.DataRequired(), validators.Regexp('^[A-Za-z ]+$', message="Only letters are allowed for name !")])
    email = EmailField('Email', [validators.DataRequired(), validators.Email(message= "Invalid Email Address")])
    type = SelectField('Enquiry Type', [validators.DataRequired()], choices=[('', 'Select'), ('Faulty Chatbot', 'Faulty Chatbot'), ('Chatbot Feedback', 'Chatbot Feedback'), ('Other', 'Other')], default='')
    remarks = StringField('Remarks', [validators.Length(min=1, max=150), validators.DataRequired()])
    confirm = BooleanField(f"Receive email confirmation of form submission")
    date = HiddenField(default=datetime.now().strftime('%Y-%m-%d'), validators=[DataRequired()])
    time = HiddenField(default=datetime.now().strftime('%H:%M'), validators=[DataRequired()])