import csv
import smtplib, urllib,webbrowser, urllib.parse
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from Forms import Create_user_appointment, CreateReportForm, Staff_Login_Form, CreateFeedbackForm, \
    Create_Contact_Us_Form, Create_Chatbot_Form
from datetime import datetime
import shelve, User_appointment, Report, Cart, Checkout, Feedback, Contact, random, Chatbot
import re


app = Flask(__name__)
# harika code
app.secret_key = 'your_secret_key'


# kar chun code
app.secret_key = 'supersecretkey'

#Pham's code


@app.route('/ChatBot')
def chat_bot():
    return render_template('chatbot.html')


@app.route('/ChatBotFAQ', methods=['GET', 'POST'])
def Chat_Bot_FAQ():
    create_chatbot_form = Create_Chatbot_Form(request.form)

    if request.method == 'POST' and create_chatbot_form.validate():
        chatbot_dict = {}
        db = shelve.open('chatbot.db', 'c')

        try:
            chatbot_dict = db['chatbot']
        except:
            print('Error in retrieving questions from chatbot.db')

        # Create a contact object with form data
        chatbot_enquiry = Chatbot.Chatbot(
            create_chatbot_form.name.data,
            create_chatbot_form.email.data,
            create_chatbot_form.type.data,
            create_chatbot_form.remarks.data,
            create_chatbot_form.date.data,
            create_chatbot_form.time.data
        )

        # Add the contact to the dictionary
        chatbot_dict[chatbot_enquiry.get_id()] = chatbot_enquiry
        db['chatbot'] = chatbot_dict
        db.close()

        sender_email = "pham.fei.ng@gmail.com"
        receiver_email = create_chatbot_form.email.data
        password = "aorf qxss smro ajne "
        subject = f"Green Gadget Chatbot Form Submission Acknowledgement"
        body = f"Hi {create_chatbot_form.name.data}, thank you for your input regarding our chatbot, we will get back to you soon"

        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject

        # Attach the email body
        message.attach(MIMEText(body, "plain"))

        if create_chatbot_form.confirm.data:
            # Set up the SMTP server
            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()  # Start TLS encryption
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message.as_string())
            server.quit()

        flash("Your form has been successfully submitted!", "success")
        return redirect(url_for('Chat_Bot_FAQ'))

    return render_template('ChatBotFAQ.html', form=create_chatbot_form)


@app.route('/RetrieveChatBotFAQ')
def Retrieve_Chat_Bot_FAQ():
    chatbot_dict = {}
    db = shelve.open('chatbot.db', 'r')

    # Try to retrieve the 'question' entry from the database. If it exists, it's loaded into questions_dict.
    chatbot_dict = db.get('chatbot', {})

    # Close the database after retrieving the data.
    db.close()

    # Dictionary to group questions by their date (we'll use this to display questions by date).
    chatbot_enquires_by_date = {}

    for key in chatbot_dict:
        # Get the actual question object using the key.
        chatbot = chatbot_dict.get(key)

        # Retrieve individual attributes from the chatbot enquiry object using the getter methods.
        chatbot_id = chatbot.get_id()
        name = chatbot.get_name()
        email = chatbot.get_email()
        type = chatbot.get_type()
        remarks = chatbot.get_remarks()
        date = chatbot.get_date()
        time = chatbot.get_time()

        # Create a dictionary representing the question with its attributes.
        chatbot_enquiry_object = {
            'id': chatbot_id,
            'name': name,
            'email': email,
            'type': type,
            'remarks': remarks,
            'time': time
        }

        # Check if the date already exists in the questions_by_date dictionary.
        # If it does, append the question to the list of questions for that date.
        if date in chatbot_enquires_by_date:
            chatbot_enquires_by_date[date].append(chatbot_enquiry_object)
        else:
            # If the date doesn't exist, create a new entry in the dictionary with the question.
            chatbot_enquires_by_date[date] = [chatbot_enquiry_object]

    # Pass 'chatbot_enquires_by_date' to the template
    return render_template('RetrieveChatBotFAQ.html', count=len(chatbot_enquires_by_date), chatbot_enquires_by_date=chatbot_enquires_by_date)


@app.route('/ReplyChatBotFAQ/<int:id>/', methods=['GET', 'POST'])
def Reply_Chat_Bot_FAQ(id):
    chatbot_dict = {}
    db = shelve.open('chatbot.db', 'r')
    chatbot_dict = db['chatbot']
    db.close()

    chatbot_enquiry = chatbot_dict.get(id)
    name = chatbot_enquiry.get_name()
    recipient_email = chatbot_enquiry.get_email()
    faq = chatbot_enquiry.get_remarks()

    # Format the subject
    subject = f"Name:{name}, Enquiry id:{id}, Enquiry:{faq}"

    # URL encode the subject to ensure it works in the mailto link
    encoded_subject = urllib.parse.quote(subject)

    # Create the mailto link with encoded subject
    mailto_link = f"mailto:{recipient_email}?subject={encoded_subject}"

    # Open the default email client
    webbrowser.open(mailto_link)

    return redirect(url_for('Retrieve_Chat_Bot_FAQ'))


@app.route('/DeleteChatBotFAQ/<int:id>', methods=['POST'])
def Delete_Chat_Bot_FAQ(id):
    chatbot_dict = {}
    db = shelve.open('chatbot.db', 'w')
    chatbot_dict = db['chatbot']
    chatbot_dict.pop(id)

    db['chatbot'] = chatbot_dict
    db.close()

    # Add flash message
    flash(f"User '{session.get('username')}'s Chatbot Question has been successfully deleted.", "success")
    return redirect(url_for('Retrieve_Chat_Bot_FAQ'))


@app.route('/ContactUs', methods=['GET', 'POST'])
def Contact_Us():
    create_question_form = Create_Contact_Us_Form(request.form)

    if request.method == 'POST' and create_question_form.validate():
        questions_dict = {}
        db = shelve.open('question.db', 'c')

        try:
            questions_dict = db['question']
        except:
            print('Error in retrieving questions from questions.db')

        # Create a contact object with form data
        contact = Contact.Question(
            create_question_form.name.data,
            create_question_form.email.data,
            create_question_form.type.data,
            create_question_form.question.data,
            create_question_form.date.data,
            create_question_form.time.data
        )

        # Add the contact to the dictionary
        questions_dict[contact.get_id()] = contact
        db['question'] = questions_dict
        db.close()

        # Send email logic (if confirm is checked)
        if create_question_form.confirm.data:
            sender_email = "pham.fei.ng@gmail.com"
            receiver_email = create_question_form.email.data
            password = "aorf qxss smro ajne"
            subject = "Green Gadget Form Submission Acknowledgement"
            body = f"Hi {create_question_form.name.data}, thank you for your enquiry, we will get back to you soon"

            message = MIMEMultipart()
            message["From"] = sender_email
            message["To"] = receiver_email
            message["Subject"] = subject
            message.attach(MIMEText(body, "plain"))

            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message.as_string())
            server.quit()

        flash("Your form has been successfully submitted!", "success")
        return redirect(url_for('Contact_Us'))

    return render_template('ContactUs.html', form=create_question_form)


@app.route('/RetrieveQuestion')
def Retrieve_Question():
    questions_dict = {}
    db = shelve.open('question.db', 'r')
    questions_dict = db.get('question', {})
    db.close()

    questions_by_date = {}

    # Organize questions by date
    for key in questions_dict:
        question = questions_dict.get(key)
        question_id = question.get_id()
        name = question.get_name()
        email = question.get_email()
        type = question.get_type()
        enquiry = question.get_question()
        date = question.get_date()
        time = question.get_time()

        # Create a dictionary for each question
        question_object = {
            'id': question_id,
            'name': name,
            'email': email,
            'type': type,
            'question': enquiry,
            'time': time
        }

        # Group questions by date
        if date in questions_by_date:
            questions_by_date[date].append(question_object)
        else:
            questions_by_date[date] = [question_object]

    return render_template('RetrieveQuestion.html', count=len(questions_by_date), questions_by_date=questions_by_date)



@app.route('/ReplyQuestion/<int:id>/', methods=['GET', 'POST'])
def Reply_Question(id):
    questions_dict = {}
    db = shelve.open('question.db', 'r')
    questions_dict = db['question']
    db.close()

    question = questions_dict.get(id)
    name = question.get_name()
    recipient_email = question.get_email()
    faq = question.get_question()

    subject = f"Name: {name}, Enquiry id: {id}, Enquiry: {faq}"
    encoded_subject = urllib.parse.quote(subject)
    mailto_link = f"mailto:{recipient_email}?subject={encoded_subject}"

    # Open the email client with the pre-filled recipient and subject
    webbrowser.open(mailto_link)

    return redirect(url_for('Retrieve_Question'))


@app.route('/DeleteQuestion/<int:id>', methods=['POST'])
def Delete_Question(id):
    questions_dict = {}
    db = shelve.open('question.db', 'w')
    questions_dict = db['question']
    questions_dict.pop(id)

    db['question'] = questions_dict
    db.close()
    username = session.get('username')
    flash(f" User {username}'s appointment has been successfully deleted!", "success")
    return redirect(url_for('Retrieve_Question'))


#chun kit's code
@app.route('/')
def About_us_home():
    return render_template('About_us_home.html')

@app.route('/user_homepage')
def user_homepage():
    return render_template("user_homepage.html")

@app.route('/staff_homepage')
def staff_homepage():
    # Retrieve 'msg' and 'first_letter' from the URL query parameters
    msg = request.args.get('msg')
    first_letter = request.args.get('first_letter')  # Get the first letter of the staff's first name

    return render_template('staff_homepage.html', msg=msg, first_letter=first_letter)

staff_credentials = {
    '256790X': ('Xavier@123A', 'Xavier Chew', 'chew_xaiver@hotmail.com'),  # staff_id: (password, name)
    '789456J': ('Jane@677S', 'Jane Smith', 'janeSmith@hotmail.com'),
    '378914S': ('Samuel@356G', 'Samuel Green','samuelGreen@hotmail.com')
}

@app.route('/staff_login', methods=['GET', 'POST'])
def staff_login():
    msg = ""
    staff_login_form = Staff_Login_Form(request.form)
    if request.method == 'POST' and staff_login_form.validate():
        # Retrieve staff_id and password from the form
        entered_staff_id = staff_login_form.staff_id.data
        entered_password = staff_login_form.password.data

        # Check if the credentials are correct in the dictionary
        if entered_staff_id in staff_credentials:
            stored_password, staff_name, staff_gmail = staff_credentials[entered_staff_id]

            if stored_password == entered_password:
                # Extract staff details and store them in session
                session['staff_id'] = entered_staff_id
                session['staff_name'] = staff_name
                session['staff_email'] = staff_gmail
                session['first_letter'] = staff_name.split()[0][0]  # First letter of first name

                # Successful login, redirect to staff homepage with the staff details
                return redirect(url_for('staff_homepage', msg=f" Staff {staff_name} has Login successfully"))
            else:
                msg = "Staff ID or Password is incorrect. Please try again."
        else:
            msg = "Staff ID or Password is incorrect. Please try again."

    return render_template('staff_login.html', form=staff_login_form, msg=msg)

@app.context_processor
def inject_staff_info():
    return {
        'staff_first_letter': session.get('first_letter'),
        'staff_id': session.get('staff_id'),
        'staff_name': session.get('staff_name'),
        'staff_email': session.get('staff_email')
    }


@app.route('/staff_view_user_appointment_page')
def staff_view_user_appointment():
    users_appointment_dict = {}
    user_appointment_db = shelve.open('user_appointment.db', 'r')
    users_appointment_dict = user_appointment_db['User_appointment']
    user_appointment_db.close()

    users_list = []
    for key in users_appointment_dict:
        user = users_appointment_dict.get(key)
        users_list.append(user)

    return render_template('staff_view_user_appointment_page.html', count=len(users_list), users_list=users_list)


@app.route('/staff_edit_user_appointment_page/<int:id>/', methods=['GET', 'POST'])
def staff_edit_user_appointment(id):
    staff_edit_user_appointment = Create_user_appointment(request.form)
    if request.method == 'POST' and staff_edit_user_appointment.validate():
        # Load existing appointments
        user_appointment_db = shelve.open('user_appointment.db', 'w')
        users_appointment_dict = user_appointment_db.get('User_appointment', {})

        # Extract new appointment details
        new_date = staff_edit_user_appointment.date_for_dropoff.data
        new_time = staff_edit_user_appointment.time_for_dropoff.data
        new_location = staff_edit_user_appointment.location.data

        # Check for conflicts with other appointments
        conflict_found = False
        for appointment_id, appointment in users_appointment_dict.items():
            if appointment_id != id:  # Exclude the current appointment being edited
                if (
                    appointment.get_date_for_dropoff() == new_date and
                    appointment.get_time_for_dropoff() == new_time and
                    appointment.get_location().lower() == new_location.lower()
                ):
                    flash("The selected time slot at this location is already booked. Please choose another time or location.", "danger")
                    conflict_found = True
                    break

        if conflict_found:
            user_appointment_db.close()
            return render_template('staff_edit_user_appointment_page.html', form=staff_edit_user_appointment)

        # Proceed with updating the appointment if no conflicts
        user = users_appointment_dict.get(id)
        selling_price_num = float(staff_edit_user_appointment.selling_price.data)
        selling_price = f'{selling_price_num:.2f}'

        user.set_first_name(staff_edit_user_appointment.first_name.data)
        user.set_last_name(staff_edit_user_appointment.last_name.data)
        user.set_email_address(staff_edit_user_appointment.email.data)
        user.set_location(staff_edit_user_appointment.location.data)
        user.set_date_for_dropoff(staff_edit_user_appointment.date_for_dropoff.data)
        user.set_time_for_dropoff(staff_edit_user_appointment.time_for_dropoff.data)
        user.set_selling_price(selling_price)
        user.set_electronic_type_selling(staff_edit_user_appointment.electronic_type_selling.data)
        user.set_message(staff_edit_user_appointment.message.data)

        user_appointment_db['User_appointment'] = users_appointment_dict
        user_appointment_db.close()

        flash(f"User '{session.get('username')}'s appointment has been successfully updated.", "success")
        return redirect(url_for('staff_view_user_appointment'))

    else:
        # Load existing data to pre-fill the form
        user_appointment_db = shelve.open('user_appointment.db', 'r')
        users_appointment_dict = user_appointment_db.get('User_appointment', {})
        user_appointment_db.close()

        user = users_appointment_dict.get(id)
        staff_edit_user_appointment.first_name.data = user.get_first_name()
        staff_edit_user_appointment.last_name.data = user.get_last_name()
        staff_edit_user_appointment.email.data = user.get_email_address()
        staff_edit_user_appointment.location.data = user.get_location()
        staff_edit_user_appointment.date_for_dropoff.data = user.get_date_for_dropoff()
        staff_edit_user_appointment.time_for_dropoff.data = user.get_time_for_dropoff()
        staff_edit_user_appointment.selling_price.data = user.get_selling_price()
        staff_edit_user_appointment.electronic_type_selling.data = user.get_electronic_type_selling()
        staff_edit_user_appointment.message.data = user.get_message()

        return render_template('staff_edit_user_appointment_page.html', form=staff_edit_user_appointment)


@app.route('/staff_delete_user_appointment_page/<int:id>', methods=['POST'])
def delete_user_appointment(id):
    users_appointment_dict = {}
    user_appointment_db = shelve.open('user_appointment.db', 'w')
    users_appointment_dict = user_appointment_db['User_appointment']

    # Remove the appointment from the dictionary
    users_appointment_dict.pop(id, None)

    user_appointment_db['User_appointment'] = users_appointment_dict
    user_appointment_db.close()

    # Flash message with the username of the logged-in user
    flash(f"User '{session.get('username')}'s appointment has been successfully deleted.", "success")

    # Redirect to the staff view page
    return redirect(url_for('staff_view_user_appointment'))


@app.route('/individual_product_page')
def individual_product_page():
        if 'username' in session:
            return render_template('individual_product_page.html', username=session['username'])
        flash("Please log in first!", "warning")
        return redirect(url_for('login'))



@app.route('/user_book_appointment_page', methods=['GET', 'POST'])
def create_user_appointment():
    create_user_appointment = Create_user_appointment(request.form)
    if request.method == 'POST' and create_user_appointment.validate():
        # Load existing appointments
        users_appointment_dict = {}
        user_appointment_db = shelve.open('user_appointment.db', 'c')
        try:
            users_appointment_dict = user_appointment_db['User_appointment']
        except KeyError:
            print("No appointments booked yet.")

        # Extract new appointment details
        new_date = create_user_appointment.date_for_dropoff.data
        new_time = create_user_appointment.time_for_dropoff.data
        new_location = create_user_appointment.location.data

        # Check for conflicts
        conflict_found = False
        for appointment in users_appointment_dict.values():
            if (
                appointment.get_date_for_dropoff() == new_date and
                appointment.get_time_for_dropoff() == new_time and
                appointment.get_location().lower() == new_location.lower()  # Case-insensitive comparison
            ):
                flash("The selected time slot at this location is already booked. Please choose another time or location.", "danger")
                conflict_found = True
                break

        if conflict_found:
            user_appointment_db.close()
            return render_template('user_book_appointment_page.html', form=create_user_appointment)

        # Proceed with creating the appointment
        selling_price_num = float(create_user_appointment.selling_price.data)
        selling_price = f'{selling_price_num:.2f}'

        user = User_appointment.User_appointment(
            create_user_appointment.first_name.data,
            create_user_appointment.last_name.data,
            create_user_appointment.email.data,
            create_user_appointment.location.data,
            create_user_appointment.date_for_dropoff.data,
            create_user_appointment.time_for_dropoff.data,
            selling_price,
            create_user_appointment.electronic_type_selling.data,
            create_user_appointment.message.data
        )

        # Save the new appointment
        users_appointment_dict[user.get_user_id()] = user
        user_appointment_db['User_appointment'] = users_appointment_dict
        user_appointment_db.close()

        flash("Your appointment has been successfully booked!", "success")
        return redirect(url_for('create_user_appointment'))

    return render_template('user_book_appointment_page.html', form=create_user_appointment)



@app.route('/user_view_appointment_page')
def user_view_appointment():
    users_appointment_dict = {}
    user_appointment_db = shelve.open('user_appointment.db', 'r')
    users_appointment_dict = user_appointment_db['User_appointment']
    user_appointment_db.close()

    users_list = []
    for key in users_appointment_dict:
        user = users_appointment_dict.get(key)
        users_list.append(user)

    return render_template('user_view_appointment_page.html', count=len(users_list), users_list=users_list)



@app.route('/user_edit_appointment_page/<int:id>/', methods=['GET', 'POST'])
def user_edit_appointment(id):
    edit_user_appointment = Create_user_appointment(request.form)
    if request.method == 'POST' and edit_user_appointment.validate():
        # Load existing appointments
        user_appointment_db = shelve.open('user_appointment.db', 'w')
        users_appointment_dict = user_appointment_db.get('User_appointment', {})

        # Extract new appointment details
        new_date = edit_user_appointment.date_for_dropoff.data
        new_time = edit_user_appointment.time_for_dropoff.data
        new_location = edit_user_appointment.location.data

        # Check for conflicts with other appointments
        conflict_found = False
        for appointment_id, appointment in users_appointment_dict.items():
            if appointment_id != id:  # Exclude the current appointment being edited
                if (
                    appointment.get_date_for_dropoff() == new_date and
                    appointment.get_time_for_dropoff() == new_time and
                    appointment.get_location().lower() == new_location.lower()
                ):
                    flash("The selected time slot at this location is already booked. Please choose another time or location.", "danger")
                    conflict_found = True
                    break

        if conflict_found:
            user_appointment_db.close()
            return render_template('user_edit_appointment_page.html', form=edit_user_appointment)

        # Proceed with updating the appointment if no conflicts
        user = users_appointment_dict.get(id)
        selling_price_num = float(edit_user_appointment.selling_price.data)
        selling_price = f'{selling_price_num:.2f}'

        user.set_first_name(edit_user_appointment.first_name.data)
        user.set_last_name(edit_user_appointment.last_name.data)
        user.set_email_address(edit_user_appointment.email.data)
        user.set_location(edit_user_appointment.location.data)
        user.set_date_for_dropoff(edit_user_appointment.date_for_dropoff.data)
        user.set_time_for_dropoff(edit_user_appointment.time_for_dropoff.data)
        user.set_selling_price(selling_price)
        user.set_electronic_type_selling(edit_user_appointment.electronic_type_selling.data)
        user.set_message(edit_user_appointment.message.data)

        user_appointment_db['User_appointment'] = users_appointment_dict
        user_appointment_db.close()

        flash("Your appointment has been successfully updated!", "success")
        return redirect(url_for('user_view_appointment'))

    else:
        # Pre-fill the form with existing appointment data
        user_appointment_db = shelve.open('user_appointment.db', 'r')
        users_appointment_dict = user_appointment_db.get('User_appointment', {})
        user_appointment_db.close()

        user = users_appointment_dict.get(id)
        edit_user_appointment.first_name.data = user.get_first_name()
        edit_user_appointment.last_name.data = user.get_last_name()
        edit_user_appointment.email.data = user.get_email_address()
        edit_user_appointment.location.data = user.get_location()
        edit_user_appointment.date_for_dropoff.data = user.get_date_for_dropoff()
        edit_user_appointment.time_for_dropoff.data = user.get_time_for_dropoff()
        edit_user_appointment.selling_price.data = user.get_selling_price()
        edit_user_appointment.electronic_type_selling.data = user.get_electronic_type_selling()
        edit_user_appointment.message.data = user.get_message()

        return render_template('user_edit_appointment_page.html', form=edit_user_appointment)






# Kar chun's code:

#notification
@app.route('/notification')
def notification():
    db = shelve.open('notification.db', writeback=True)
    username = session.get('username')
    user_id = session.get('user_id')
    notification_dict = db.get(user_id, {})
    notifications = []

    for username, messages in notification_dict.items():  # iterate over key-value pairs
        for message_data in messages:  # Loop through the list of messages
            time = message_data.get('time')
            message = message_data.get('message')
            notifications.append(f"{time}: {message}")  # Store messages correctly for display
    # To make the latest notifications appear at the top
    notifications = reversed(notifications)
    # Reset notification count in session without deleting notifications
    session['notification_count'] = 0

    db[user_id] = notification_dict
    db.close()

    return render_template('notification.html',notifications = notifications)

def get_latest_notification(username):
    db = shelve.open('notification.db', 'c')
    user_id = session.get('user_id')
    notification_dict = db.get(user_id, {})
    user_notifications = notification_dict.get(username, [])
    db.close()

    # get the latest message from user_notifications if user_notifications is not empty
    if user_notifications:
        return user_notifications[-1] # retrieve the last notification from the list which is the latest notification
    else:
        return None # if empty return none

@app.route('/get_latest_notification')
def get_latest_notification_route():
    if 'username' in session:
        username = session['username']
        latest_notification = get_latest_notification(username) # call the function to get the latest notification

        # return the notification in JSON format
        if latest_notification:
            return jsonify({'notification': latest_notification})
        else:
            return jsonify({'notification': None})



# add notification using by getting the username and message
def add_notification(username, message):
    notification_dict = {}
    db = shelve.open('notification.db', 'c')
    user_id = session.get('user_id')
    notification_dict = db.get(user_id,{})

    # if the username is not in notification_dict, create an empty list
    if username not in notification_dict:
        notification_dict[username] = []

    #create a message entry with time and date
    message_data = {
        'message' : message,
        'time' : datetime.now().strftime('%d %B %Y, %I:%M %p')
    }

    #append the new message to the user notification list
    notification_dict[username].append(message_data)
    db[user_id] = notification_dict
    db.close()

    # Update the session notification count
    if 'notification_count' in session:
        session['notification_count'] = session.get('notification_count', 0) + 1
    else:
        session['notification_count'] = 1



@app.route('/get_notification_count')
def get_notification_count():
    if 'username' not in session:
        return jsonify({"count": 0}) # if is not log in, return notification as 0

    username = session['username']

    # If notification count is set in session, use that
    if 'notification_count' in session:
        count = session['notification_count']
    else:
        # Otherwise calculate from database
        db = shelve.open('notification.db', 'r')
        notification_dict = db.get('notifications', {})
        db.close()

        user_notifications = notification_dict.get(username, [])
        count = len(user_notifications)
        session['notification_count'] = count
    return jsonify({"count": session['notification_count']})



# Cart count
@app.context_processor
def cart_quantity():
    try:
        cart_dict = {}
        cart_db = shelve.open('cart.db', 'r')
        user_id = session.get('user_id')
        cart_dict = cart_db[user_id]

        total_quantity = 0

        # This is to loop each item_id in the cart_dict and add the quantity to the total
        for item_id, item_value in cart_dict.items():
            item = cart_dict[item_id]
            total_quantity += item.get_quantity()

        cart_db.close()
        return {'total_quantity': total_quantity}
    except:
        return {'total_quantity': 0}


@app.route("/add-to-cart", methods=['POST'])
def add_to_cart():
    item_image = request.form['item_image']
    item_name = request.form['item_name']
    price = int(request.form['price'])
    quantity = int(request.form['quantity'])

    cart_dict = {}
    db = shelve.open('cart.db', 'c')
    user_id = session.get('user_id')
    try:
        cart_dict = db[user_id]
    except:
        print("Error in retrieving cart from cart.db.")

    # Check if the item is already in the cart using name
    existing_item = None
    for item_id, item_value in cart_dict.items():
        if item_name == item_value.get_item_name():
            existing_item = item_id
            break

    # if the item is not inside the cart
    if existing_item == None:
        item_id = str(len(cart_dict) + 1)
        cart_item = Cart.Cart(item_id, item_name, price, quantity, item_image)
        cart_dict[item_id] = cart_item
    else:
        # if the item is inside the cart
        item = cart_dict[existing_item]
        new_quantity = item.get_quantity() + quantity  # The value is assigned in HTML
        item.set_quantity(new_quantity)

    db[user_id] = cart_dict
    db.close()
    flash(f"Added {item_name} to cart!", 'success')
    return redirect(url_for('individual_product_page'))


@app.route('/cart')
def cart():
    cart_dict = {}
    db = shelve.open('cart.db', 'r')
    user_id = session.get('user_id')
    cart_dict = db.get(user_id, {})
    db.close()

    items = []
    total_price = 0

    # Loop each items in the cart_dict and append all the attibutes to the list and access the items to display in the HTML
    for key, value in cart_dict.items():
        item_name = value.get_item_name()
        item_price = value.get_price()
        item_quantity = value.get_quantity()
        item_image = value.get_item_image()
        item_subtotal = item_price * item_quantity
        item = {
            'id': key,
            'name': item_name,
            'price': item_price,
            'quantity': item_quantity,
            'image': item_image,
            'subtotal': item_subtotal
        }
        items.append(item)
        total_price += item['subtotal']

    return render_template('cart.html', items=items, total=total_price)


@app.route('/updateCart/<int:item_id>', methods=['POST'])
def update_cart(item_id):
    cart_dict = {}
    db = shelve.open('cart.db', 'w')
    user_id = session.get('user_id')
    cart_dict = db[user_id]

    # Access the item using the item id to make changes
    item_id = str(item_id)
    cart = cart_dict[item_id]
    action = request.form['action']
    # it is a html button that have a value
    if action == 'decrement' and cart.get_quantity() > 1:
        cart.set_quantity(cart.get_quantity() - 1)
    elif action == 'increment':
        cart.set_quantity(cart.get_quantity() + 1)

    db[user_id] = cart_dict
    db.close()
    return redirect(url_for('cart'))


@app.route('/deleteCart/<int:item_id>', methods=['POST'])
def delete_cart(item_id):
    cart_dict = {}
    db = shelve.open('cart.db', 'w')
    user_id = session.get('user_id')
    cart_dict = db[user_id]

    item_id = str(item_id)
    delete_item = cart_dict.pop(item_id)

    db[user_id] = cart_dict
    db.close()
    return redirect(url_for('cart'))


@app.route("/check-out", methods=['GET', 'POST'])
def check_out():
    checkOut_dict = {}
    db = shelve.open('cart.db', 'r')
    user_id = session.get('user_id')
    checkOut_dict = db.get(user_id, {})
    db.close()

    items = []
    base_price = 0
    # It is in this format {item_key{item_name,item_price...}} same as the cart which is used to display attibutes in check out page
    for item_key, item_value in checkOut_dict.items():
        item_name = item_value.get_item_name()
        item_price = item_value.get_price()
        item_quantity = item_value.get_quantity()
        item_subtotal = "{:.2f}".format(item_price * item_quantity)
        item = {
            'id': item_key,
            'name': item_name,
            'price': item_price,
            'quantity': item_quantity,
            'subtotal': item_subtotal
        }
        items.append(item)
        base_price = float(base_price)
        base_price += float(item['subtotal'])
    base_price = "{:.2f}".format(base_price)

    # if the cart is empty a message will pop out prompting them to add items
    if items == []:
        flash("Your cart is empty. Add items before checking out.")
        return redirect(url_for('cart'))

    return render_template("checkout.html", items=items, base_price=base_price)

@app.route('/confirmation')
def confirmation():
    username = session.get('username')
    add_notification(username, 'Payment successful, view your order in Purchase History')
    return render_template('confirmation.html', username= session.get('username'))



@app.route('/process_checkout', methods=['POST'])
def process_checkout():
    user_id = session.get('user_id')

    # Open transaction database
    db = shelve.open('transaction.db', 'c')
    transaction_dict = db.get('transaction', {})

    # Retrieve order details
    order_db = shelve.open('cart.db', 'r')
    order_dict = order_db.get(user_id, {})
    order_db.close()

    cart_list_user = []  # For user-specific history
    cart_list_staff = []  # For staff-wide history

    # Open user history DB
    user_history_db = shelve.open('user_history.db', 'c')
    cart_list_user = user_history_db.get(str(user_id), [])  # Get only this user's history

    # Open staff history DB
    staff_history_db = shelve.open('staff_history.db', 'c')
    cart_list_staff = staff_history_db.get('staff_history', [])  # Get all transactions

    transaction_items = []
    transaction_id = str(len(transaction_dict) + 1)
    total_price = 0

    # Open inventory database to update stock
    inventory_db = shelve.open('inventory.db', 'c')
    inventory = inventory_db.get('inventory', {})

    for item_key, item_value in order_dict.items():
        item_name = item_value.get_item_name().lower()  # Normalize item name to lowercase
        item = {
            'id': item_key,
            'image': item_value.get_item_image(),
            'name': item_value.get_item_name(),
            'price': item_value.get_price(),
            'quantity': item_value.get_quantity(),
            'subtotal': item_value.get_price() * item_value.get_quantity(),
        }
        transaction_items.append(item)
        total_price += item['subtotal']

        # Normalize inventory keys to lowercase
        inventory = {k.lower(): v for k, v in inventory.items()}

        # Check and update stock
        if item_name in inventory and inventory[item_name] >= item['quantity']:
            inventory[item_name] -= item['quantity']
        else:
            inventory_db.close()
            return jsonify({"message": f"Insufficient stock for {item['name']}"}), 400

    # Save updated inventory
    inventory_db['inventory'] = inventory
    inventory_db.close()

    transaction_data = {
        'transaction_id': transaction_id,
        'user_id': user_id,
        'items': transaction_items,
        'total_price': total_price,
        'date': datetime.now().strftime('%I:%M %p, %d %B %Y'),
        'delivery_status': 'Processing'
    }

    # Append to both user and staff history
    cart_list_user.append(transaction_data)
    cart_list_staff.append(transaction_data)

    # Save user history
    user_history_db[str(user_id)] = cart_list_user
    user_history_db.close()

    # Save staff history
    staff_history_db['staff_history'] = cart_list_staff
    staff_history_db.close()

    # Save transaction details
    transaction_dict[transaction_id] = request.form.to_dict()
    db['transaction'] = transaction_dict
    db.close()

    # Clear user's cart
    order_db = shelve.open('cart.db', 'w')
    order_db[user_id] = {}  # Empty cart
    order_db.close()

    return redirect(url_for('confirmation'))



@app.route('/purchase_history')
def purchase_history():
    user_id = session.get('user_id')
    user_history_db = shelve.open('user_history.db', 'r')
    cart_list = user_history_db.get(str(user_id), [])
    user_history_db.close()
    return render_template('purchase_history.html', cart_list=cart_list)

# Xavier's code:

@app.route('/viewUserPurchases')
def view_user_purchases():
    # Load purchase history from 'staff_history.db' (staff view)
    staff_history_db = shelve.open('staff_history.db', 'r')
    cart_list = staff_history_db.get('staff_history', [])  # Get all purchases
    staff_history_db.close()

    # Load transaction data from 'transaction.db'
    transaction_db = shelve.open('transaction.db', 'r')
    transaction_dict = transaction_db.get('transaction', {})
    transaction_db.close()

    # Merge customer info with each purchase using transaction_id
    for transaction in cart_list:
        transaction_id = transaction.get('transaction_id')

        # Check if transaction_id exists in transaction_dict
        customer_info = transaction_dict.get(transaction_id, {})

        # Add customer info if found, else set as 'Unknown'
        transaction['customer_name'] = customer_info.get('name', "Unknown")
        transaction['customer_email'] = customer_info.get('email', "Unknown")
        transaction['customer_address'] = customer_info.get('address', "Unknown")
        transaction['shipping_option'] = customer_info.get('shipping_option', "Unknown")

    # Pass the merged cart_list to the template for rendering
    return render_template('view_user_purchases.html', cart_list=cart_list)

@app.route('/update_delivery_status', methods=['POST'])
def update_delivery_status():
    # Get form data
    purchase_id = request.form['id']
    new_status = request.form['delivery_status']

    # Open staff history database
    staff_history_db = shelve.open('staff_history.db', 'c')
    cart_list_staff = staff_history_db.get('staff_history', [])

    # Update the delivery status in staff history
    for transaction in cart_list_staff:
        if transaction['transaction_id'] == purchase_id:
            transaction['delivery_status'] = new_status
            break

    # Save updated staff history
    staff_history_db['staff_history'] = cart_list_staff
    staff_history_db.close()

    # Now, update the corresponding transaction in user history
    user_history_db = shelve.open('user_history.db', 'c')
    user_cart_list = user_history_db.get(str(transaction['user_id']), [])  # Get the user-specific history

    # Update the delivery status for the user's specific purchase
    for transaction in user_cart_list:
        if transaction['transaction_id'] == purchase_id:
            transaction['delivery_status'] = new_status
            username = session.get('username')
            add_notification(username, f'Order Updated! Order is now {new_status}')
            break

    # Save the updated user history
    user_history_db[str(transaction['user_id'])] = user_cart_list
    user_history_db.close()
    flash(f"{session.get('username')}'s delivery status has been successfully changed to \"{new_status}\"", 'success')
    # Redirect back to the staff purchase history page
    return redirect(url_for('view_user_purchases'))



@app.route('/retrieveReport')
def retrieve_report():
    return render_template('retrieveReport.html')



from werkzeug.utils import secure_filename


@app.route('/inventoryManagement')
def inventory_management():
    try:
        # Open inventory database
        db = shelve.open('inventory.db', 'c')
        inventory = db.get('inventory', {})

        # Initialize inventory if empty
        if not inventory:
            inventory = {
                "iphone 13": 200,
                "macbook air 13": 150,
                "samsung flip": 300,
                "google pixel": 120,
                "hp laptop": 180,
                "apple ipad": 456,
                "asus laptop": 678,
                "logitech ipad": 987,
                "samsung tablet": 654,
                "iphone 16": 768,
                "samsung galaxy fold 4": 123,
                "xiaomi 12 pro": 200,
                "sony speaker": 567,
                "bose mini speaker": 133,
                "jdl speaker": 666,
                "samsung watch":78,
                "apple watch se":99,
                "google pixel watch": 777,

            }
            db['inventory'] = inventory
        db.close()

        # Fetch stock history from stock_history.db
        history_db = shelve.open('stock_history.db', 'c')
        stock_history = history_db.get('history', [])  # This ensures stock_history is always an empty list if no data
        history_db.close()

        # Get updated inventory
        db = shelve.open('inventory.db', 'c')
        inventory = db.get('inventory', {})
        db.close()

        items = list(inventory.keys())
        stock_levels = list(inventory.values())

        # Pass stock_history to the template
        return render_template('inventory_management.html', items=items, stock_levels=stock_levels,
                               stock_history=stock_history)

    except Exception as e:
        return jsonify({"message": "Error retrieving report", "error": str(e)}), 500


@app.route('/updateStock', methods=['POST'])
def update_stock():
    try:
        # Retrieve staff details from session
        staff_id = session.get('staff_id', 'Unknown')  # Retrieve staff_id from session
        staff_name = session.get('staff_name', 'Unknown')  # Retrieve staff_name from session

        data = request.get_json()

        if not data:
            return jsonify({"message": "No JSON data received"}), 400

        item_name = data.get('name', '').strip()
        item_quantity = data.get('quantity')

        if not item_name or item_quantity is None or not staff_id or not staff_name:
            return jsonify({"message": "Invalid input"}), 400

        try:
            item_quantity = int(item_quantity)  # Ensure quantity is an integer
        except ValueError:
            return jsonify({"message": "Quantity must be a valid integer"}), 400

        # Open inventory database
        db = shelve.open('inventory.db', 'c')
        inventory = db.get('inventory', {})

        if item_name in inventory:
            inventory[item_name] += item_quantity
            db['inventory'] = inventory
            db.close()
        else:
            db.close()
            return jsonify({"message": f"Item '{item_name}' not found"}), 404

        # Log stock update
        history_db = shelve.open('stock_history.db', 'c')
        history = history_db.get('history', [])

        history.append({
            'item_name': item_name,
            'quantity_updated': item_quantity,
            'staff_id': staff_id,  # Use staff_id from session
            'staff_name': staff_name,  # Use staff_name from session
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })

        history_db['history'] = history
        history_db.close()

        return jsonify({"message": "Update successful", "new_stock": inventory[item_name], "stock_history": history})

    except Exception as e:
        return jsonify({"message": "Server error", "error": str(e)}), 500

@app.route('/uploadCSV', methods=['POST'])
def upload_csv():
    try:
        # Retrieve staff details from session
        staff_id = session.get('staff_id', 'Unknown')  # Retrieve staff_id from session
        staff_name = session.get('staff_name', 'Unknown')  # Retrieve staff_name from session

        # Ensure a file was uploaded
        if 'file' not in request.files:
            print("No file part")
            return jsonify({"message": "No file part"}), 400
        file = request.files['file']

        if file.filename == '':
            print("No selected file")
            return jsonify({"message": "No selected file"}), 400

        # Secure the filename and check extension
        filename = secure_filename(file.filename)
        if not filename.endswith('.csv'):
            print("Only CSV files are allowed")
            return jsonify({"message": "Only CSV files are allowed"}), 400

        # Read the CSV content
        csv_content = csv.reader(file.stream.read().decode('utf-8').splitlines())

        # Open the inventory database
        db = shelve.open('inventory.db', 'c')
        inventory = db.get('inventory', {})

        # Open the stock history database
        history_db = shelve.open('stock_history.db', 'c')
        history = history_db.get('history', [])

        for row in csv_content:
            if len(row) != 2:
                print(f"Skipping invalid row: {row}")
                continue  # Skip invalid rows
            item_name, item_quantity = row
            try:
                item_quantity = int(item_quantity.strip())
            except ValueError:
                print(f"Invalid quantity value in row: {row}")
                continue  # Skip rows with invalid quantity

            if item_name in inventory:
                inventory[item_name] += item_quantity
            else:
                inventory[item_name] = item_quantity

            # Log each stock update
            history.append({
                'item_name': item_name,
                'quantity_updated': item_quantity,
                'staff_id': staff_id,  # Use staff_id from session
                'staff_name': staff_name,  # Use staff_name from session
                'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })

        # Save the updated inventory back into the database
        db['inventory'] = inventory
        db.close()

        # Save the updated history back into the database
        history_db['history'] = history
        history_db.close()

        print("Stock updated successfully")
        return jsonify({"message": "Stock updated successfully", "stock_history": history}), 200

    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({"message": "Server error", "error": str(e)}), 500



@app.route('/monthly_sales', methods=['GET'])
def monthly_sales():
    try:
        # Get the year from query parameters (defaults to 2025)
        year = int(request.args.get('year', 2025))

        # Initialize sales_data
        sales_data = {}

        # Static data for previous years
        if year == 2024:
            sales_data = {
                1: 45000, 2: 32000, 3: 37000, 4: 28000, 5: 42000, 6: 46000,
                7: 49000, 8: 40000, 9: 36000, 10: 39000, 11: 51000, 12: 57000
            }
        elif year == 2023:
            sales_data = {
                1: 43000, 2: 31000, 3: 36000, 4: 28000, 5: 40000, 6: 45000,
                7: 48000, 8: 39000, 9: 35000, 10: 38000, 11: 50000, 12: 56000
            }
        elif year == 2022:
            sales_data = {
                1: 41000, 2: 30000, 3: 35000, 4: 27000, 5: 38000, 6: 44000,
                7: 47000, 8: 38000, 9: 34000, 10: 37000, 11: 49000, 12: 55000
            }
        elif year == 2021:
            sales_data = {
                1: 39000, 2: 29000, 3: 33000, 4: 26000, 5: 36000, 6: 42000,
                7: 45000, 8: 37000, 9: 33000, 10: 36000, 11: 47000, 12: 53000
            }
        elif year == 2020:
            sales_data = {
                1: 37000, 2: 28000, 3: 31000, 4: 25000, 5: 34000, 6: 40000,
                7: 43000, 8: 36000, 9: 32000, 10: 35000, 11: 46000, 12: 52000
            }
        # Handle 2025 year dynamically
        elif year == 2025:
            # Initialize sales data for January 2025
            sales_data = {1: 46320}  # Static data for January
            for month in range(2, 13):  # Start from February to December
                sales_data[month] = 0

            # Accessing staff_history.db to aggregate data
            try:
                print("Attempting to open staff_history.db...")

                # Open the staff_history_db instead of user_history_db
                db = shelve.open('staff_history.db', 'r')
                staff_history_list = db.get('staff_history', [])

                # Debug: Print the staff_history_list to see its contents
                print(f"Loaded staff_history_list: {staff_history_list}")

                if not staff_history_list:
                    print("No history data found in the database.")
                    db.close()
                    return jsonify({"error": "No history data found"}), 404

                for transaction_data in staff_history_list:
                    # Get date and total price from each transaction
                    date_str = transaction_data.get('date')
                    total_price = float(transaction_data.get('total_price', 0))

                    if date_str:  # Check if the date is not None or empty
                        try:
                            date_obj = datetime.strptime(date_str, '%I:%M %p, %d %B %Y')
                        except ValueError as e:
                            print(f"Date parsing error for transaction: {e}")
                            continue  # Skip this transaction if date parsing fails

                        # If the date is valid and matches the requested year
                        if date_obj.year == year:
                            month = date_obj.month
                            if month != 1:  # January is already set
                                sales_data[month] += total_price
                    else:
                        print(f"Missing or invalid date for transaction, skipping.")

                db.close()  # Close the staff_history DB after processing
                print(f"Sales data for year {year}: {sales_data}")

            except Exception as e:
                print(f"Error accessing staff_history.db: {str(e)}")
                return jsonify({"error": f"Error accessing the staff history database: {str(e)}"}), 500

        else:
            # Default: Return empty data for years other than the ones above
            sales_data = {month: 0 for month in range(1, 13)}

        # Return the sales data as JSON
        return jsonify(sales_data)

    except Exception as e:
        print(f"Internal server error: {str(e)}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

@app.route('/top_5_products', methods=['GET'])
def top_5_products():
    try:
        # Initialize product_sales
        product_sales = {}

        # Accessing staff_history.db to aggregate product sales
        try:
            print("Attempting to open staff_history.db...")

            # Open the staff_history_db instead of user_history_db
            db = shelve.open('staff_history.db', 'r')
            staff_history_list = db.get('staff_history', [])

            if not staff_history_list:
                print("No history data found in the database.")
                db.close()
                return jsonify({"error": "No history data found"}), 404

            for transaction_data in staff_history_list:
                # Update product_sales with sales for each product in this transaction
                for item in transaction_data.get('items', []):
                    product_name = item.get('name')
                    product_price = item.get('price')
                    product_quantity = item.get('quantity')
                    total_product_sales = product_price * product_quantity

                    # Add to the product sales dictionary
                    if product_name in product_sales:
                        product_sales[product_name] += total_product_sales
                    else:
                        product_sales[product_name] = total_product_sales

            db.close()  # Close the staff_history DB after processing

        except Exception as e:
            print(f"Error accessing staff_history.db: {str(e)}")
            return jsonify({"error": f"Error accessing the staff history database: {str(e)}"}), 500

        # Now calculate the top 5 products by sales
        top_5_products = sorted(product_sales.items(), key=lambda x: x[1], reverse=True)[:5]

        # Prepare the response data for top 5 products
        top_5_products_response = [{"product_name": name, "total_sales": sales} for name, sales in top_5_products]
        print(f"Top 5 products: {top_5_products_response}")

        # Return the top 5 products as JSON
        return jsonify({"top_5_products": top_5_products_response})

    except Exception as e:
        print(f"Internal server error: {str(e)}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500


@app.route('/top_5_products_qty', methods=['GET'])
def top_5_products_qty():
    try:
        # Initialize product_sales
        product_sales = {}

        # Accessing staff_history.db to aggregate product sales
        try:
            print("Attempting to open staff_history.db...")

            # Open the staff_history_db instead of user_history_db
            db = shelve.open('staff_history.db', 'r')
            staff_history_list = db.get('staff_history', [])

            if not staff_history_list:
                print("No history data found in the database.")
                db.close()
                return jsonify({"error": "No history data found"}), 404

            for transaction_data in staff_history_list:
                # Update product_sales with quantity for each product in this transaction
                for item in transaction_data.get('items', []):
                    product_name = item.get('name')
                    product_quantity = item.get('quantity')

                    # Add to the product sales dictionary
                    if product_name in product_sales:
                        product_sales[product_name] += product_quantity
                    else:
                        product_sales[product_name] = product_quantity

            db.close()  # Close the staff_history DB after processing

        except Exception as e:
            print(f"Error accessing staff_history.db: {str(e)}")
            return jsonify({"error": f"Error accessing the staff history database: {str(e)}"}), 500

        # Now calculate the top 5 products by quantity sold
        top_5_products = sorted(product_sales.items(), key=lambda x: x[1], reverse=True)[:5]

        # Prepare the response data for top 5 products
        top_5_products_response = [{"product_name": name, "quantity_sold": quantity} for name, quantity in top_5_products]
        print(f"Top 5 products by quantity sold: {top_5_products_response}")

        # Return the top 5 products as JSON
        return jsonify({"top_5_products_qty": top_5_products_response})

    except Exception as e:
        print(f"Internal server error: {str(e)}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500


@app.route('/customer_purchase_trends', methods=['GET'])
def customer_purchase_trends():
    try:
        # Initialize data structure to store total spend and count of customers per month
        purchase_trends = {}

        # Accessing staff_history.db to aggregate customer purchase data
        try:
            print("Attempting to open staff_history.db...")

            # Open the staff_history_db
            db = shelve.open('staff_history.db', 'r')
            staff_history_list = db.get('staff_history', [])

            if not staff_history_list:
                print("No history data found in the database.")
                db.close()
                return jsonify({"error": "No history data found"}), 404

            for transaction_data in staff_history_list:
                # Aggregate purchase data by month (you can adjust this to be by year as well)
                transaction_date = transaction_data.get('date')
                customer_id = transaction_data.get('customer_id')
                total_spend = sum(item['price'] * item['quantity'] for item in transaction_data.get('items', []))

                # Extract month and year from the date (assuming it's in 'YYYY-MM-DD' format)
                year_month = transaction_date[:7]  # Format: 'YYYY-MM'

                # Add to the purchase_trends dictionary
                if year_month not in purchase_trends:
                    purchase_trends[year_month] = {'total_spend': 0, 'total_customers': 0}

                purchase_trends[year_month]['total_spend'] += total_spend
                purchase_trends[year_month]['total_customers'] += 1

            db.close()  # Close the staff_history DB after processing

        except Exception as e:
            print(f"Error accessing staff_history.db: {str(e)}")
            return jsonify({"error": f"Error accessing the staff history database: {str(e)}"}), 500

        # Now calculate the average spend per customer per month
        purchase_trends_response = [{
            'month': month,
            'average_purchase_value': data['total_spend'] / data['total_customers'] if data['total_customers'] > 0 else 0
        } for month, data in purchase_trends.items()]

        print(f"Customer purchase trends: {purchase_trends_response}")

        # Return the data as JSON
        return jsonify({"customer_purchase_trends": purchase_trends_response})

    except Exception as e:
        print(f"Internal server error: {str(e)}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500


class User:
    def __init__(self, user_id, first_name, last_name, dob, email, username, password):
        self.user_id = user_id
        self.first_name = first_name
        self.last_name = last_name
        self.dob = dob
        self.email = email
        self.username = username
        self.password = password

    def get_user_id(self):
        if hasattr(self, 'user_id'):
            return self.user_id
        else:
            print("user_id attribute not found!")
            return None

def is_valid_password(password):
    if len(password) < 8:
        return False
    if len(re.findall(r'\d', password)) < 2:
        return False
    return True

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        dob = request.form['dob']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if not is_valid_password(password):
            flash("Password must be at least 8 characters long and include at least 2 numbers.", "danger")
            return render_template('signup.html', first_name=first_name, last_name=last_name, dob=dob, email=email, username=username)

        users_dict = {}
        db = shelve.open('user.db', 'c')

        try:
            users_dict = db['Users']
        except:
            print("Error in retrieving Users from user.db.")

        if username in users_dict:
            db.close()
            flash("Username already exists!", "danger")
            return render_template('signup.html', first_name=first_name, last_name=last_name, dob=dob, email=email)

        if password != confirm_password:
            flash("Passwords do not match!", "danger")
            return render_template('signup.html', first_name=first_name, last_name=last_name, dob=dob, email=email,
                                   username=username)
        # Create a new User object with a unique user ID
        user_id = len(users_dict) + 1
        user = User(user_id, first_name ,last_name, dob, email, username, password)
        users_dict[username] = user
        db['Users'] = users_dict
        db.close()

        flash("Signup successful! You can now log in.", "success")
        return redirect(url_for('login'))

    return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        users_dict = {}
        db = shelve.open('user.db', 'r')

        try:
            users_dict = db['Users']
        except:
            print("Error in retrieving Users from user.db.")

        user = users_dict.get(username)
        db.close()


        if user and user.password == password:
            # Store the user's name in session (you can store more details if needed)
            session['username'] = username
            session['user_name'] = user.first_name  # Store user's first name in session
            session['user_last_name'] = user.last_name
            session['email'] = user.email  # Retrieve email from user object
            session['date_of_birth'] = user.dob  # Retrieve date of birth from user object

            user_id = user.get_user_id()
            session['user_id'] = str(user_id)
            session['notification_shown'] = False

            # Create a custom flash message with the user's name
            flash(f"User '{user.first_name} {user.last_name}' has logged in successfully ! Welcome to GreenGadgets !", "success")
            return redirect(url_for('individual_product_page'))

        flash("Username or Password is invalid!", "danger")
        return redirect(url_for('login'))

    return render_template('login.html')

@app.context_processor
def inject_user_info():
    return {
        'user_name': session.get('user_name'),
        'user_last_name': session.get('user_last_name'),
        'username': session.get('username'),
        'email': session.get('email'),
        'date_of_birth': session.get('date_of_birth')
    }

@app.route('/SendFeedback', methods= ['GET', 'POST'])
def Send_Feedback():
    create_feedback_form = CreateFeedbackForm(request.form)

    if request.method == 'POST' and create_feedback_form.validate():
        feedback_dict = {}
        db = shelve.open('feedback.db', 'c')

        try:
            feedback_dict = db['feedback']
        except:
            print('Error in retrieving questions from feedback.db')

        # Create a contact object with form data
        feedback = Feedback.Feedback(
            create_feedback_form.name.data,
            create_feedback_form.email.data,
            create_feedback_form.who.data,
            create_feedback_form.type.data,
            create_feedback_form.feedback.data,
            create_feedback_form.date.data,
            create_feedback_form.time.data
        )

        # Add the contact to the dictionary
        feedback_dict[feedback.get_id()] = feedback
        db['feedback'] = feedback_dict
        db.close()

        sender_email = "pham.fei.ng@gmail.com"
        receiver_email = create_feedback_form.email.data
        password = "aorf qxss smro ajne "
        subject = f"Green Gadget Form Submission Acknowledgement"
        body = f"Hi {create_feedback_form.name.data}, thank you for your submitting your feedback, we will get back to you soon"

        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject

        # Attach the email body
        message.attach(MIMEText(body, "plain"))

        if create_feedback_form.confirm.data:
            # Set up the SMTP server
            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()  # Start TLS encryption
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message.as_string())
            server.quit()

        flash("Your form has been successfully submitted!", "success")
        return redirect(url_for('Send_Feedback'))

    return render_template('SendFeedback.html', form=create_feedback_form)

@app.route('/RetrieveFeedback')
def Retrieve_Feedback():
    feedback_dict = {}
    db = shelve.open('feedback.db', 'r')
    feedback_dict = db.get('feedback', {})
    db.close()

    feedbacks_by_date = {}  # Initialize the dictionary to store feedback grouped by date

    for key in feedback_dict:
        feedback = feedback_dict.get(key)
        feedback_id = feedback.get_id()
        name = feedback.get_name()
        email = feedback.get_email()
        who = feedback.get_who()  # Added the missing function call for 'who'
        type = feedback.get_type()
        enquiry = feedback.get_feedback()
        date = feedback.get_date()
        time = feedback.get_time()

        feedback_object = {
            'id': feedback_id,
            'name': name,
            'email': email,
            'who': who,  # Corrected 'who' to be consistent
            'type': type,
            'feedback': enquiry,
            'time': time
        }

        # Group feedback by date
        if date in feedbacks_by_date:
            feedbacks_by_date[date].append(feedback_object)
        else:
            feedbacks_by_date[date] = [feedback_object]

    # Return the feedback grouped by date to the template
    return render_template('RetrieveFeedback.html', count=len(feedbacks_by_date), feedbacks_by_date=feedbacks_by_date)


@app.route('/ReplyFeedback/<int:id>/', methods=['GET', 'POST'])
def Reply_Feedback(id):
    feedback_dict = {}
    db = shelve.open('feedback.db', 'r')
    feedback_dict = db['feedback']
    db.close()

    feedback = feedback_dict.get(id)
    name = feedback.get_name()
    recipient_email = feedback.get_email()
    faq = feedback.get_feedback()

    # Format the subject
    subject = f"Name:{name}, Enquiry id:{id}, Enquiry:{faq}"

    # URL encode the subject to ensure it works in the mailto link
    encoded_subject = urllib.parse.quote(subject)

    # Create the mailto link with encoded subject
    mailto_link = f"mailto:{recipient_email}?subject={encoded_subject}"

    # Open the default email client
    webbrowser.open(mailto_link)

    return redirect(url_for('Retrieve_Feedback'))

@app.route('/DeleteFeedback/<int:id>', methods=['POST'])
def Delete_Feedback(id):
    feedback_dict = {}
    db = shelve.open('feedback.db', 'w')
    feedback_dict = db['feedback']
    feedback_dict.pop(id)

    db['feedback'] = feedback_dict
    db.close()

    flash(f"User '{session.get('username')}' feedback has been successfully deleted.", "success")
    return redirect(url_for('Retrieve_Feedback'))



PROMO_CODES = ["CODE"]

@app.route('/instructions')
def index():
    return render_template('instructions.html')

@app.route('/memory_game')
def memory_game():
    return render_template('memory_game.html')

@app.route('/get_promo')
def get_promo():
    return random.choice(PROMO_CODES)


if __name__ == '__main__':
    app.run(debug=True)
