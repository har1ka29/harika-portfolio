class Report:
    count_report = 0

    def __init__(self, staff_id, name, income, spending, date):
        Report.count_report += 1
        self.__staff_no = Report.count_report
        self.__staff_id = staff_id
        self.__name = name
        self.__income = float(income)
        self.__spending = float(spending)

        self.__date = date

    def get_staff_no(self):
        return self.__staff_no

    def get_staff_id(self):
        return self.__staff_id

    def get_name(self):
        return self.__name

    def get_income(self):
        return round(float(self.__income), 2)

    def get_spending(self):
        return round(float(self.__spending), 2)

    def get_date(self):
        return self.__date

    def set_staff_id(self, staff_id):
        self.__staff_id = staff_id

    def set_name(self, name):
        self.__name = name

    def set_income(self, income):
        self.__income = float(income)

    def set_spending(self, spending):
        self.__spending = float(spending)

    def set_date(self, date):
        self.__date = date

    def compute_earnings(self):
        return float(self.__income) - float(self.__spending)
